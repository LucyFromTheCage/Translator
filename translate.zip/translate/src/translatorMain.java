import java.util.Scanner;
public class translatorMain {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Language trans = new Language();
        String[] Nationalities = trans.getNats();
        String choice;
        while (true) {
            System.out.println("What nationality would you like to translate to?");
            for (int x = 0; x <= Nationalities.length - 1; x++) {
                System.out.print(Nationalities[x] + "\t");
                if(x%2==0 && x!=0){
                    System.out.println();
                }
            }
            System.out.println("\nPlease check spelling before entering!");
            choice = input.nextLine();
            System.out.println("You have chosen " + choice);
            if (ChoiceReal(choice.toLowerCase(), Nationalities)) {
                break;
            } else {
                System.out.println("INVALID OPTION\nPlease enter a new option");
            }
        }
        System.out.println("Please enter the sentence you would like to translate to "+choice+":");
        String translateSentence = input.nextLine();
        System.out.println("Translating...");
        trans.setParam(choice.toLowerCase(), translateSentence);
        System.out.println(trans);
    }


    private static boolean ChoiceReal(String CheckChoice, String[] options) {
        for(int x = 0; x<options.length;x++){
            if(options[x].equals(CheckChoice)){
                return true;
            }
        }
        return false;
    }

}

