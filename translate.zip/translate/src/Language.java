public class Language {
    private String ending;
    private String beginning;
    private String language;
    private String sent;
    private String replace;
    private char finalChar = '.';
    private String[] Nationalities = {"canadian", "minnesota", "redneck", "australian"};

    public Language(){
    }

    public String[] getNats(){
        return Nationalities;
    }

    public void setParam(String newLang, String newSent) {
        language = newLang;
        sent = newSent;
    }

    public String toString(){
        if(language.equals("canadian")){
            return canadian(sent);
        }else if(language.equals("minnesota")){
            return minnesota(sent);
        } else if (language.equals("redneck")) {
            return redneck(sent);
        }else if(language.equals(Nationalities[3])){
            return australian(sent);
        }else{
            return "ERROR\nERRROR";
        }
    }

    private String canadian(String sentence) {
        ending = " eh";
        if (sentence.contains(".") || sentence.contains("?") || sentence.contains("!")) {
            finalChar = sentence.charAt((sentence.length()-1));
            sent = sentence.substring(0, sentence.length() - 1);
        } else {
            sent = sentence;
        }
        return sent + ending + finalChar;
    }

    private String minnesota(String sentence){
        beginning = "Oh yeah there bud! ";
        ending = " donchano";
        if (sentence.contains(".") || sentence.contains("?") || sentence.contains("!")) {
            finalChar = sentence.charAt((sentence.length()-1));
            sent = sentence.substring(0, sentence.length() - 1);
        } else {
            sent = sentence;
        }
        return beginning + sent + ending + finalChar;
    }

    private String redneck(String sentence){
        replace = "YEEHAW!";
        sent = sentence;
        return replace;
    }

    private String australian(String sentence){
        ending = ", mate";
        if (sentence.contains(".") || sentence.contains("?") || sentence.contains("!")) {
            finalChar = sentence.charAt((sentence.length()-1));
            sent = sentence.substring(0, sentence.length() - 1);
        } else {
            sent = sentence;
        }
        return sent + ending + finalChar;
    }
}
